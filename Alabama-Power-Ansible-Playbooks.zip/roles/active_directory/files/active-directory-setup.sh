update-crypto-policies --set DEFAULT:AD-SUPPORT
foreman-maintain packages install -y adcli krb5-workstation oddjob oddjob-mkhomedir authconfig sssd
adcli join {{ domain_name }} -U {{ adcli_user }}
authconfig --enablesssd --enablesssdauth --enablelocauthorize --enablemkhomedir --update
authselect select sssd with-mkhomedir --force
systemctl start sssd
systemctl enable --now oddjobd.service
sss_cache -E
